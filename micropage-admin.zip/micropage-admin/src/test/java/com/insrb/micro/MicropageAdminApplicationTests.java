package com.insrb.micro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicropageAdminApplicationTests {

    @Test
    void contextLoads() {
    }

}
