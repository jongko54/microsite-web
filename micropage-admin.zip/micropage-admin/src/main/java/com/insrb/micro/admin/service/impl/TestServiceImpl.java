package com.insrb.micro.admin.service.impl;

import org.springframework.stereotype.Service;

/**
 * service impl 패키지
 */
@Service
public class TestServiceImpl {
}
