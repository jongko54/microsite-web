package com.insrb.micro.admin.service;

import com.insrb.micro.admin.domain.dto.request.InsuAgentReqDto;
import com.insrb.micro.admin.domain.dto.response.CommunityResDto;
import com.insrb.micro.admin.domain.dto.response.ExcelAgentResDto;
import com.insrb.micro.admin.domain.dto.response.GeneralMemberResDto;
import com.insrb.micro.admin.domain.dto.response.InsuAgentResDto;
import com.insrb.micro.admin.domain.entity.Community;
import com.insrb.micro.admin.domain.entity.GeneralMember;
import com.insrb.micro.admin.domain.entity.InsuAgent;
import com.insrb.micro.admin.domain.entity.common.Paging;
import com.insrb.micro.admin.repository.GeneralMemberRepository;
import com.insrb.micro.admin.repository.InsuAgentRepository;
import com.insrb.micro.utils.ExcelUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class InsuAgentService {


    private final ExcelUtils excelUtils;
    private final InsuAgentRepository insuAgentRepository;
    private final GeneralMemberRepository generalMemberRepository;

    //엑셀 헤더
    final String[] HEADER = {"회사명","비즈로보ID","이름"};

    public Paging selectList(MultiValueMap<String, String> formData) {

        int draw = Integer.parseInt(formData.get("draw").get(0));
        int start = Integer.parseInt(formData.get("start").get(0));
        int length = Integer.parseInt(formData.get("length").get(0));
        int page =  start / length;

        Paging pagingDto = new Paging();

        //page = offset , length = limit
        Pageable pageable = PageRequest.of(page, length, Sort.by(Sort.Direction.DESC, "id"));

        String searchTitleValue = formData.get("columns[3][search][value]").get(0);
        String searchCreatedByValue = formData.get("columns[5][search][value]").get(0);
        Page<InsuAgent> list = null;

        //검색 값 여부에 따라 분기 처리
        if(!searchTitleValue.isEmpty()){
            //타이틀 검색 like sql
//              list = communityRepository.findAllByTitleContaining(pageable, searchTitleValue);

        }else if (!searchCreatedByValue.isEmpty()) {
            //작성자 검색 like sql
//            list = communityRepository.findAllByCreatedByContaining(pageable, searchCreatedByValue);

        }else{
            //전체 검색x
            list = insuAgentRepository.findAll(pageable);
        }

        List<InsuAgentResDto> listToDto = list.stream().map(InsuAgentResDto::new).collect(Collectors.toList());

        int total = Long.valueOf(list.getTotalElements()).intValue();

        pagingDto.setDraw(draw);
        pagingDto.setRecordsFiltered(total);
        pagingDto.setRecordsTotal(total);
        pagingDto.setData(listToDto);

        return pagingDto;
    }

    public void excelFormDownload(HttpServletResponse response) {

        try{
            Workbook workbook = new SXSSFWorkbook();
            Sheet sheet = workbook.createSheet("설계사 가입");

            //숫자 포맷 적용
            CellStyle cellStyle = workbook.createCellStyle();
            cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("#,##0"));

            //파일명
            final String FILE_NAME = "설계사 가입";

            Row row = sheet.createRow(0);

            for(int i=0; i<HEADER.length; i++){
                Cell cell = row.createCell(i);
                cell.setCellValue(HEADER[i]);
            }

            response.setHeader("Content-Disposition", "attachment;filename="+ URLEncoder.encode(FILE_NAME,"UTF-8")+".xlsx");

            ServletOutputStream out = response.getOutputStream();
            workbook.write(out);
            out.close();


        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public List<ExcelAgentResDto> excelUpload(MultipartHttpServletRequest request) throws IOException {



        MultipartFile file = null;
        Iterator<String> mIterator = request.getFileNames();
        if(mIterator.hasNext()) {
            file = request.getFile(mIterator.next());
        }

        List<ExcelAgentResDto> listData = new ArrayList<>();
        List<String> listId = new ArrayList<>();
        //
        List<Map<String,Object>> listParse = excelUtils.getListData(file, 1, 3, HEADER);

        for(Map<String,Object> map : listParse){
            ExcelAgentResDto dto = new ExcelAgentResDto();
            dto.setCompanyName(map.get("0").toString());
            dto.setInsuId(map.get("1").toString());
            dto.setInsuName(map.get("2").toString());

            listId.add(map.get("1").toString());
            listData.add(dto);
        }

        System.out.println(listId.toString());

        List<GeneralMemberResDto> bizroboId = generalMemberRepository.findByUserIdIn(listId).stream().map(GeneralMemberResDto::new).collect(Collectors.toList());

        List<String> test = new ArrayList<>();

        for(String insuId : listId){

            for(GeneralMemberResDto item : bizroboId){
                if(!insuId.equals(item.getUserId())){
                    System.out.println("들어온값 : " + insuId);
                    System.out.println("쿼리값 : " + item.getUserId());
                    test.add(insuId);
                }
            }
        }

        System.out.println("테스트 : " + test.toString());

//
//        try{
//            //엑셀파일 열기(2007이상)
//            OPCPackage opcPackage = OPCPackage.open(file.getInputStream());
//            XSSFWorkbook wb = new XSSFWorkbook(opcPackage);
//
//
//            //sheet수
//            int sheetNum = wb.getNumberOfSheets();
//
//            for(int num=0; num<sheetNum; num++){
//
//                XSSFSheet sheet = wb.getSheetAt(num);
//                Iterator<Row> iterator = sheet.iterator();
//
//                //row
//                while(iterator.hasNext()){
//                    Row currentRow = iterator.next();
//                    Iterator<Cell> cellIterator = currentRow.iterator();
//
//
//                    //cell
//                    while (cellIterator.hasNext()){
//                        Cell currentCell = cellIterator.next();
//
//                        if(currentCell.getCellType() == CellType.STRING){
//                            System.out.print(currentCell.getStringCellValue() + "\t");
//                        }else if(currentCell.getCellType() == CellType.NUMERIC){
//                            System.out.print((int)currentCell.getNumericCellValue() + "\t");
//                        }
//                    }
//                    System.out.println();
//
//                }
//
//            }
//
//            opcPackage.close();
//        } catch (Exception  e) {
//            throw new RuntimeException(e);
//        }



        return listData;
    }

    public List<InsuAgentResDto> excelSave(List<InsuAgentReqDto> params) {

        List<InsuAgent> paramsToEntity = params.stream().map(m->m.toEntity()).collect(Collectors.toList());

        List<InsuAgent> resEntity = insuAgentRepository.saveAll(paramsToEntity);

        return resEntity.stream().map(InsuAgentResDto :: new).collect(Collectors.toList());
    }
}
