package com.insrb.micro.api.domain.dto.request;

import lombok.Data;

@Data
public class PhoneUpdateRequestDto {

    private String messageId;
    private String phoneRole;
}
