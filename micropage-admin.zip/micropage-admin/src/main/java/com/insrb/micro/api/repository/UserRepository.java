package com.insrb.micro.api.repository;

import com.insrb.micro.api.domain.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUserId(String userId);
    Optional<User> findByUserIdAndLoginType(String userId, String loginType);
    List<User> findAllByPhoneRoleAndDeleteYn(String mobile, char deleteYn);
    Optional<User> findById(long id);
}
