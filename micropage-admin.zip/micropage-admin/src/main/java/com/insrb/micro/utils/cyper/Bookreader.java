package com.insrb.micro.utils.cyper;

public class Bookreader {
    public  static String reader(){
        return "GXC42A";
    }
}
