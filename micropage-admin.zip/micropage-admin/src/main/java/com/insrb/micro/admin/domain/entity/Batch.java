package com.insrb.micro.admin.domain.entity;


public class Batch {
}
