package com.insrb.micro.admin.repository;

import com.insrb.micro.admin.domain.entity.InsuAgent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface InsuAgentRepository extends JpaRepository<InsuAgent, Long> {
}
