package com.insrb.micro.api.repository;

import com.insrb.micro.api.domain.entity.Consulting;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsultingApiRepository extends JpaRepository<Consulting, Long> {

}
