package com.insrb.micro.api.controller;

import com.insrb.micro.api.common.ApiResponse;
import com.insrb.micro.api.common.ResponseUtil;
import com.insrb.micro.api.common.SuccessCode;
import com.insrb.micro.api.domain.dto.request.UserJoinRequestDto;
import com.insrb.micro.api.domain.dto.response.FindEmailResponseDto;
import com.insrb.micro.api.domain.dto.response.TokenInfo;
import com.insrb.micro.api.domain.dto.request.UserLoginRequestDto;
import com.insrb.micro.api.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 사용자 관련 요청을 처리하는 컨트롤러
 * @RestController로 처리
 */

@Api(tags = "user(사용자)")
@Slf4j
@RequestMapping("/api/public")
@RestController
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;


    /**
     * 사용자 로그인 api
     * @param params (이메일, 비밀번호)
     * @return jwt토큰, 사용자 이름
     */
    @ApiOperation(value = "사용자 로그인")
    @PostMapping(path = "/login")
    public ApiResponse login(@RequestBody UserLoginRequestDto params){

        TokenInfo tokenInfo = userService.login(params.getUserId(), params.getUserPw());


        return ResponseUtil.SUCCESS(SuccessCode.SUCCESS_LOGIN, tokenInfo);
    }

    /**
     * 회원가입 api
     * @param params (이메일, 비밀번호, 이름, 전화번호)
     * @return 이메일
     */
    @ApiOperation(
            value = "사용자 회원가입"
                    )
    @PostMapping(path = "/join")
    public ApiResponse signup(@RequestBody UserJoinRequestDto params){

        String createdUserId = userService.join(params);

        return ResponseUtil.SUCCESS(SuccessCode.SUCCESS_JOIN, createdUserId);
    }

    /**
     * 이메일 중복확인 api
     * @param email (이메일)
     * @return true or false
     */
    @ApiOperation(
            value = "이메일 중복확인",
            notes = "true면 중복되는 이메일 없음 false면 중복되는 이메일"
    )
    @GetMapping(path = "/email")
    public ApiResponse emailCheck(@RequestParam String email){
        return ResponseUtil.SUCCESS(SuccessCode.SUCCESS_CHECK ,userService.emailCheck(email));
    }

    @ApiOperation(value = "사용자 아이디 찾기")
    @GetMapping(path = "/findEmail")
    public ApiResponse findEmail(@RequestParam String mobile, String messageId){

        return ResponseUtil.SUCCESS(SuccessCode.SUCCESS_OK, userService.findEmail(mobile, messageId));
    }


    @ApiOperation(value = "api 요청 테스트")
    @GetMapping(path = "/test")
    public ApiResponse test(HttpServletRequest request, HttpServletResponse response) throws IOException {

//        String test = userService.test("테스트2");

        System.out.println("testetetet");

//        String url = UriComponentsBuilder.fromUriString("http://localhost:3000/login")
//
//                .build().toUriString();

        return ResponseUtil.SUCCESS(SuccessCode.SUCCESS_OK, "성공");

//        response.sendRedirect(url);
    }

}
