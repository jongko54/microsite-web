package com.insrb.micro.api.service;


import com.insrb.micro.api.common.Utils;
import com.insrb.micro.api.domain.dto.request.UserJoinRequestDto;
import com.insrb.micro.api.domain.dto.response.AgreementResponseDto;
import com.insrb.micro.api.domain.dto.response.FindEmailResponseDto;
import com.insrb.micro.api.domain.dto.response.TokenInfo;
import com.insrb.micro.api.config.security.jwt.TokenProvider;
import com.insrb.micro.api.domain.entity.Sms;
import com.insrb.micro.api.domain.entity.User;
import com.insrb.micro.api.exception.CustomException;
import com.insrb.micro.api.exception.ErrorCode;
import com.insrb.micro.api.repository.SmsRepository;
import com.insrb.micro.api.repository.UserRepository;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {


    private final UserRepository userRepository;
    private final SmsRepository smsRepository;
    private final TokenProvider tokenProvider;
    private final PasswordEncoder passwordEncoder;


    @Transactional
    public TokenInfo login(String userId, String userPw){

        String loginType = "insurobo";
        //아이디 존재 여부
        User user = userRepository.findByUserIdAndLoginType(userId, loginType).orElseThrow(()-> new CustomException(ErrorCode.USER_NOT_FOUND));

        //암호화된 비밀번호 비교
        if(!passwordEncoder.matches(userPw, user.getUserPw())){
            throw new CustomException(ErrorCode.PASSWORD_NOT_EQUALS);
        }

//        Authentication authentication = new UserAuthentication(userId, null, null);

        //로그인된 사용자 정보로 토큰 생성
        TokenInfo tokenInfo = tokenProvider.generateToken(userId, user.getId());

        Claims claims = tokenProvider.parseClaims(tokenInfo.getAccessToken());

        tokenInfo.setUserName(user.getUserName());

        return tokenInfo;
    }

    @Transactional
    public String join(UserJoinRequestDto params) {

        //비밀번호 암호화
        params.setUserPw(passwordEncoder.encode(params.getUserPw()));

        User user = userRepository.save(params.toEntity());


        if(user.getUserId().isEmpty() || user.getUserId() == null){
            throw new CustomException(ErrorCode.FAIL_JOIN);
        }

        return user.getUserId();
    }


    @Transactional
    public boolean emailCheck(String email) {
        Optional<User> entity = userRepository.findByUserId(email);

        boolean emailChk = true;

        if(!entity.isEmpty()){
            System.out.println("유저 있음");
            //값이 있으면 이미 사용중인 이메일이므로 예외처리 해준다
            throw new CustomException(ErrorCode.FAIL_EMAIL_DUP);
        }

        return emailChk;
    }

    @Transactional
    public List<FindEmailResponseDto> findEmail(String mobile, String messageId) {

        Sms smsYn = smsRepository.findByMessageId(messageId).orElseThrow(()-> new CustomException(ErrorCode.FAIL_SMS));

        //인증이 완료되지 않았을때 예외발생
        if(smsYn.getAuthYn() != 'Y'){
            throw new CustomException(ErrorCode.FAIL_SMS);
        }

        //인증번호 시간이 만료되었을때 예외발생
        if(!Utils.getAuthTimeDiff(smsYn.getSendDate())){
            throw new CustomException(ErrorCode.FAIL_TIME_MOBILE);
        }

        List<User> entity = userRepository.findAllByPhoneRoleAndDeleteYn(mobile, 'N');

        //계정이 존재하지 않을경우 예외발생
        if(entity.isEmpty()){
            throw new CustomException(ErrorCode.USER_NOT_FOUND);
        }

        return entity.stream().map(FindEmailResponseDto::new).collect(Collectors.toList());
    }


    public String test(String name) {

        if(!name.equals("테스트")){
            throw new CustomException(ErrorCode.BAD_REQUEST);
        }else{
            return "일치";
        }
    }
}
